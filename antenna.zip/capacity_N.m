naz = [7; 11; 16; 24; 32;];
nel = [36; 56; 76; 106; 151;];
n_arr = naz .* nel;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h = figure;
set(h,'PaperType','A4');
axes('FontSize',16);
subplot(1,2,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(n_arr, capacity(1:length(n_arr), 3), 'k--d','LineWidth',2,'MarkerSize',14)
hold on
plot(n_arr, capacity(1:length(n_arr), 1), 'k--^','LineWidth',2,'MarkerSize',14)
plot(n_arr, capacity(1:length(n_arr), 6), 'k--x','LineWidth',2,'MarkerSize',10)
plot(n_arr, capacity(1:length(n_arr), 4), 'k--v','LineWidth',2,'MarkerSize',10)
plot(n_arr, capacity(1:length(n_arr), 12), 'k-o','LineWidth',2,'MarkerSize',10)
plot(n_arr, capacity(1:length(n_arr), 9), 'k-s','LineWidth',2,'MarkerSize',10)
xlim([min(n_arr), max(n_arr)])
ylim([0,500])
le = legend('Beamspace based [28]','TDMA+[28]', 'Pilot based [27]','TDMA+[27]','Proposed','Perfect', 'Location', 'northwest');
set(le,'Fontsize',16,'Fontname','Times')
set(gca,'XTick',n_arr)
xlabel('Number of the BS antennas N','Fontsize',20,'Fontname','Times')
ylabel('Spectral efficiency (bps/Hz)','Fontsize',20,'Fontname','Times')
grid on

subplot(1,2,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(n_arr, nmse(1:length(n_arr), 3), 'k--d','LineWidth',2,'MarkerSize',14)
hold on
plot(n_arr, nmse(1:length(n_arr), 6), 'k--x','LineWidth',2,'MarkerSize',10)
plot(n_arr, nmse(1:length(n_arr), 12), 'k-o','LineWidth',2,'MarkerSize',10)
xlim([min(n_arr), max(n_arr)])
ylim([0,200])
le = legend('Beamspace based [28]', 'Pilot based [27]','Proposed', 'Location', 'northwest');
set(le,'Fontsize',16,'Fontname','Times')
set(gca,'XTick',n_arr)
xlabel('Number of the BS antennas N','Fontsize',20,'Fontname','Times')
ylabel('NMSE','Fontsize',20,'Fontname','Times')
grid on
print(h,'-dpdf','fig_n')
